var a = 10;
let b = 20;
var myName = "林小妹";
var age = 18;
document.write('<h1> 我是\'林小妹\'，今年'+age+'歲')
document.write('<h1> 數字:', a, '+', b, ' = ',a+b)
document.write('<h1> 字串:', a, '+', b, ' = '+a+b)